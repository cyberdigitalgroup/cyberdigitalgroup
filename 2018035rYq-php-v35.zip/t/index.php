<?php
header('Location: http://wonderselect.com/clicks?cid=22037&pub=200845&sid1=&sid2=&sid3=&sid4=&tt=27');
exit;
?>