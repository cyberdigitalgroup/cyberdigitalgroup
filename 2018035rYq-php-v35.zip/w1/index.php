<?php
header('Location: http://wonderselect.com/clicks?cid=21490&pub=200845&sid1=&sid2=&sid3=&sid4=&tt=27');
exit;
?>