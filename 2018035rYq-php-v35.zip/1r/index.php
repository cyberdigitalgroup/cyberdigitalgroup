<?php
header('Location: http://wonderselect.com/clicks?cid=22144&pub=200686&sid1=&sid2=&sid3=&sid4=&tt=27');
exit;
?>