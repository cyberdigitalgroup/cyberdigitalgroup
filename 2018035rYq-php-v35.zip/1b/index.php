<?php
header('Location: http://wonderselect.com/clicks?cid=13408&pub=200845&sid1=&sid2=&sid3=&sid4=&tt=27');
exit;
?>